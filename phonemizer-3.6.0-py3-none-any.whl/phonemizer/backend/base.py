# Copyright 2015-2021 Mathieu Bernard
#
# This file is part of phonemizer: you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# Phonemizer is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with phonemizer. If not, see <http://www.gnu.org/licenses/>.
"""Abstract base class for phonemization backends"""

import abc
import itertools
from logging import Logger
from typing import Optional, List, Any, Dict, Tuple, Union, Pattern

import joblib

from phonemizer.logger import default_logger
from phonemizer.punctuation import Punctuation
from phonemizer.separator import Separator, default_separator
from phonemizer.utils import chunks


class BaseBackend(abc.ABC):
    """Abstract base class of all the phonemization backends

    Provides a common interface to all backends. The central method is
    `phonemize()`

    Parameters
    ----------
    language: str
        The language code of the input text, must be supported by
        the backend. If ``backend`` is 'segments', the language can be a file with
        a grapheme to phoneme mapping.

    preserve_punctuation: bool
        When True, will keep the punctuation in the
        phonemized output. Not supported by the 'espeak-mbrola' backend. Default
        to False and remove all the punctuation.

    punctuation_marks: str
        The punctuation marks to consider when dealing with punctuation, either for removal or preservation.
        Can be defined as a string or regular expression. Default to Punctuation.default_marks().

    logger: logging.Logger
        the logging instance where to send
        messages. If not specified, use the default system logger.

    Raises
    ------
    RuntimeError
        if the backend is not available of if the `language` cannot be initialized.

    """
    # When preserving the punctuation, phonemize the words on both sides of
    # quotes or brackets in context. Disabled in the backends that phonemize
    # each word alone, or with no word separation.
    _punctuation_context = True

    def __init__(self, language: str,
                 punctuation_marks: Optional[Union[str, Pattern]] = None,
                 preserve_punctuation: bool = False,
                 logger: Optional[Logger] = None):

        if punctuation_marks is None:
            punctuation_marks = Punctuation.default_marks()

        if logger is None:
            logger = default_logger()

        # ensure the backend is installed on the system, telling why if not
        reason = self._unavailable_reason()
        if reason is not None:
            raise RuntimeError(
                f'{self.name()} not installed on your system'
                + (f': {reason}' if reason else ''))

        self._logger = logger
        self._logger.info(
            'initializing backend %s-%s',
            self.name(), '.'.join(str(v) for v in self.version()))

        # ensure the backend support the requested language
        self._language = self._init_language(language)

        # setup punctuation processing
        self._preserve_punctuation = preserve_punctuation
        self._punctuator = Punctuation(punctuation_marks)

    @classmethod
    def _init_language(cls, language):
        """Language initialization

        This method may be overloaded in child classes (see Segments backend)

        """
        code = cls._supported_language(language)
        if code is None:
            raise RuntimeError(
                f'language "{language}" is not supported by the '
                f'{cls.name()} backend')
        return code

    @property
    def logger(self):
        """A logging.Logger instance where to send messages"""
        return self._logger

    @property
    def language(self):
        """The language code configured to be used for phonemization"""
        return self._language

    @staticmethod
    @abc.abstractmethod
    def name():
        """The name of the backend"""

    @classmethod
    @abc.abstractmethod
    def is_available(cls):
        """Returns True if the backend is installed, False otherwise"""

    @classmethod
    def _unavailable_reason(cls) -> Optional[str]:
        """Returns why the backend is not available, None if it is

        The reason is given in the error raised when the backend cannot be
        initialized. To be overloaded in child classes that can explain it.

        """
        return None if cls.is_available() else ''

    @classmethod
    @abc.abstractmethod
    def version(cls):
        """Return the backend version as a tuple (major, minor, patch)"""

    @staticmethod
    @abc.abstractmethod
    def supported_languages() -> Dict[str, str]:
        """Return a dict of language codes -> name supported by the backend"""

    @classmethod
    def _installation(cls) -> tuple:
        """Returns the configuration of the backend installation in use

        This is part of the key of the backends cached by phonemize(), so
        that a backend is reloaded when its installation changes. To be
        overloaded in child classes that can be configured.

        """
        return ()

    @classmethod
    def is_supported_language(cls, language: str):
        """Returns True if `language` is supported by the backend

        Language codes are case insensitive: 'en-US' is supported as 'en-us'.

        """
        return cls._supported_language(language) is not None

    @classmethod
    def _supported_language(cls, language: str) -> Optional[str]:
        """Returns the supported language code matching `language`

        Returns None if `language` is not supported. The language codes are
        compared ignoring case, the returned code is as listed by
        supported_languages().

        """
        supported = cls.supported_languages()
        if language in supported:
            return language
        matches = [
            code for code in supported
            if code.lower() == str(language).lower()]
        return matches[0] if len(matches) == 1 else None

    def phonemize(self, text: List[str],
                  separator: Optional[Separator] = None,
                  strip: bool = False,
                  njobs: int = 1) -> List[str]:
        """Returns the `text` phonemized for the given language

        Parameters
        ----------
        text: list of str
            The text to be phonemized. Each string in the list
            is considered as a separated line. Each line is considered as a text
            utterance. Any empty utterance will be ignored.

        separator: Separator
            string separators between phonemes, syllables
            and words, default to separator.default_separator. Syllable separator
            is considered only for the festival backend. Word separator is
            ignored by the 'espeak-mbrola' backend.

        strip: bool
            If True, don't output the last word and phone separators
            of a token, default to False.

        njobs : int
            The number of parallel jobs to launch. The input text is
            split in ``njobs`` parts, phonemized on parallel instances of the
            backend and the outputs are finally collapsed.

        Returns
        -------
        phonemized text: list of str
            The input ``text`` phonemized for the given ``language`` and ``backend``.

        Raises
        ------
        RuntimeError
            if something went wrong during the phonemization

        """
        if isinstance(text, str):
            # changed in phonemizer-3.0, warn the user
            raise RuntimeError(
                'input text to phonemize() is str but it must be list of str')

        if separator is None:
            separator = default_separator

        text, punctuation_marks = self._phonemize_preprocess(text)

        # When preserving the punctuation, the chunks separated by inline marks
        # (quotes or brackets) are phonemized as a whole as well, appended to
        # the text, so that their words are pronounced in context.
        context = (
            self._punctuator.inline_groups(punctuation_marks)
            if (self._preserve_punctuation and self._punctuation_context
                and Punctuation.can_align(separator))
            else [])
        text = text + [
            ' '.join(text[chunk] for chunk in group) for group in context]

        if njobs == 1:
            # phonemize the text forced as a string
            phonemized = self._phonemize_aux(text, 0, separator, strip)
        else:
            # If using parallel jobs, disable the log as stderr is not
            # picklable.
            self.logger.info('running %s on %s jobs', self.name(), njobs)

            # we have here a list of phonemized chunks
            phonemized = joblib.Parallel(n_jobs=njobs)(
                joblib.delayed(self._phonemize_aux)(
                    # chunk[0] is the text, chunk[1] is the offset
                    chunk[0], chunk[1], separator, strip)
                for chunk in zip(*chunks(text, njobs)))

            # flatten them in a single list
            phonemized = self._flatten(phonemized)

        phonemized, context = self._split_context(phonemized, context)
        if self._preserve_punctuation:
            punctuation_marks = (punctuation_marks, context)
        return self._phonemize_postprocess(
            phonemized, punctuation_marks, separator, strip)

    @staticmethod
    def _split_context(phonemized: List[str], context: List[List[int]]) \
            -> Tuple[List[str], List[Tuple[List[int], str]]]:
        """Splits the phonemized chunks from the groups phonemized in context

        The last lines of `phonemized` are the groups of chunks in `context`,
        phonemized as a whole. Returns the phonemized chunks and the pairs
        (group, phonemized group). This method may be overloaded in child
        classes, along with _phonemize_aux() (see espeak backend).

        """
        nchunks = len(phonemized) - len(context)
        return phonemized[:nchunks], list(zip(context, phonemized[nchunks:]))

    @staticmethod
    def _flatten(phonemized: List[List[Any]]):
        """Flatten a list of lists into a single one

        From [[1, 2], [3], [4]] returns [1, 2, 3, 4]. This method is used to
        format the output as obtained using multiple jobs.

        """
        return list(itertools.chain(*phonemized))

    @abc.abstractmethod
    def _phonemize_aux(self, text: List[str], offset: int, separator: Separator, strip: bool) -> List[str]:
        """The "concrete" phonemization method

        Must be implemented in child classes. `separator` and `strip`
        parameters are as given to the phonemize() method. `text` is as
        returned by _phonemize_preprocess(). `offset` is line number of the
        first line in `text` with respect to the original text (this is only
        usefull with running on chunks in multiple jobs. When using a single
        jobs the offset is 0).

        """

    def _phonemize_preprocess(self, text: List[str]) -> Tuple[Union[str, List[str]], List]:
        """Preprocess the text before phonemization

        Removes the punctuation (keep trace of punctuation marks for further
        restoration if required by the `preserve_punctuation` option).

        """
        if self._preserve_punctuation:
            # a tuple (chunks, parts of each line)
            return self._punctuator.preserve(text)
        return self._punctuator.remove(text), []

    def _phonemize_postprocess(self, phonemized: List[str],
                               punctuation_marks,
                               separator: Separator,
                               strip: bool):
        """Postprocess the raw phonemized output

        Restores the punctuation as needed. When preserving the punctuation,
        `punctuation_marks` is the parts of each line, as returned by
        _phonemize_preprocess(), along with the groups phonemized in context
        as returned by _split_context().

        """
        if self._preserve_punctuation:
            lines, context = punctuation_marks
            return self._punctuator.restore(
                phonemized, lines, separator, strip, context)
        return phonemized
